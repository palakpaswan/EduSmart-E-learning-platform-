
package demoP;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


public class EditProjectTitle extends HttpServlet {
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String courseId = request.getParameter("course_id");
        String projectTitle = request.getParameter("project_title");
        
        // Database connection details
        String dbUrl = "jdbc:mysql://localhost:3306/User";
        String dbUser = "root";
        String dbPassword = "root";
        
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            
            String updateQuery = "UPDATE Courses SET project_title = ? WHERE course_id = ?";
            PreparedStatement stmt = conn.prepareStatement(updateQuery);
            stmt.setString(1, projectTitle);
            stmt.setInt(2, Integer.parseInt(courseId));
            
            int rowsUpdated = stmt.executeUpdate();
            
            // Redirect with a success message
            if (rowsUpdated > 0) {
                response.sendRedirect("ManageProject.jsp?message=Project title updated successfully&type=success");
            } else {
                response.sendRedirect("ManageProject.jsp?message=Error updating project title&type=error");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ManageProject.jsp?message=Error updating project title&type=error");
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

