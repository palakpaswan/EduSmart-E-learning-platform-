package demoP;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class ForgotPasswordServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String email = request.getParameter("email");
        String role = request.getParameter("role");
        String otpMessage = ""; // Message to send to the JSP page
        String otp = ""; // OTP generated to send to user
        boolean emailExists = false;

        if (email != null && role != null) {
    // Check if email exists and send OTP if valid
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
        // Load MySQL JDBC driver
        Class.forName("com.mysql.jdbc.Driver");

        // Database connection
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "root");

        // Query to check if email exists for the given role
        String query = "SELECT 1 FROM " + role + " WHERE TRIM(LOWER(email)) = ?";
        ps = conn.prepareStatement(query);
        ps.setString(1, email.trim().toLowerCase());
        rs = ps.executeQuery();

        // If email exists, generate OTP and send it
        if (rs.next()) {
            emailExists = true;
            otpMessage = "Email exists. An OTP has been sent to your email address.";

            // Generate OTP
            otp = generateOTP();
            session.setAttribute("otp", otp);
            session.setAttribute("email", email);
            session.setAttribute("role", role);

            // Send OTP to user's email
            sendOTPEmail(email, otp);
            
            request.setAttribute("otpMessage", otpMessage);
            // Forward to the OTP verification page
            RequestDispatcher dispatcher = request.getRequestDispatcher("/verifyOTP.jsp");
            dispatcher.forward(request, response);

        } else {
            otpMessage = "Email not found for the selected role.";
            request.setAttribute("otpMessage", otpMessage); // Set the message in request scope
            // Forward back to the forgot password page with the error message
            RequestDispatcher dispatcher = request.getRequestDispatcher("/forgotPassword.jsp");
            dispatcher.forward(request, response);
        }

    } catch (SQLException | ClassNotFoundException e) {
        otpMessage = "Error: " + e.getMessage();
        request.setAttribute("otpMessage", otpMessage); // Set the error message in request scope
        // Forward to the forgot password page in case of error
        RequestDispatcher dispatcher = request.getRequestDispatcher("/forgotPassword.jsp");
        dispatcher.forward(request, response);
    } finally {
        try { if (rs != null) rs.close(); } catch (SQLException ignored) {}
        try { if (ps != null) ps.close(); } catch (SQLException ignored) {}
        try { if (conn != null) conn.close(); } catch (SQLException ignored) {}
    }
}

        

       
        
    }

    // Generate OTP
    private String generateOTP() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000); // Generate 6-digit OTP
        return String.valueOf(otp);
    }

    // Send OTP via email
    private void sendOTPEmail(String recipientEmail, String otp) {
        String host = "smtp.gmail.com";
        String user = "palakpaswan456@gmail.com";  
        String pass = "lqoe bfoh xahx xddv";   
        String from = "palakpaswan456@gmail.com";
        String subject = "Your OTP for Forgot Password";
        String messageText = "Your OTP is: " + otp;

        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, pass);
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipientEmail));
            message.setSubject(subject);
            message.setText(messageText);

            Transport.send(message);
        } catch (MessagingException e) {
            
        }
    }
}
