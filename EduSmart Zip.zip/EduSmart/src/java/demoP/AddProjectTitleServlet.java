package demoP;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AddProjectTitleServlet extends HttpServlet {

    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String courseId = request.getParameter("course_id");
        String projectTitle = request.getParameter("project_title");

        String dbUrl = "jdbc:mysql://localhost:3306/User";
        String dbUser = "root";
        String dbPassword = "root";

        String message;
        String messageType;

        try {
            // Database connection
            Class.forName("com.mysql.jdbc.Driver"); // Use the correct MySQL driver class
            Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);

            // Update the project_title for the selected course
            String query = "UPDATE Courses SET project_title = ? WHERE course_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, projectTitle);
            stmt.setInt(2, Integer.parseInt(courseId));

            int rowsUpdated = stmt.executeUpdate();
            stmt.close();
            conn.close();

            if (rowsUpdated > 0) {
                message = "Project title added successfully!";
                messageType = "success";
            } else {
                message = "Failed to update project title. Course not found.";
                messageType = "error";
            }
        } catch (Exception e) {
            message = "An error occurred: " + e.getMessage();
            messageType = "error";
        }

        // Redirect back to the ManageProject.jsp with message and type as query parameters
        response.sendRedirect("ManageProject.jsp?message=" + message + "&type=" + messageType);
    }
}
