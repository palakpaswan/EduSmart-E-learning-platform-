package demoU;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AddCourseServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Getting course details
        String courseName = request.getParameter("course_name");
        String videoUrl = request.getParameter("video_url");

        try {
            // Establishing connection to MySQL database
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "root");

            // Inserting course into courses table
            String courseQuery = "INSERT INTO courses (course_name, video_url) VALUES (?, ?)";
            PreparedStatement coursePs = connection.prepareStatement(courseQuery, Statement.RETURN_GENERATED_KEYS);
            coursePs.setString(1, courseName);
            coursePs.setString(2, videoUrl);
            coursePs.executeUpdate();

            // Getting generated course_id
            ResultSet rs = coursePs.getGeneratedKeys();
            int courseId = 0;
            if (rs.next()) {
                courseId = rs.getInt(1);
            }

            // Inserting questions and options
            String[] questions = request.getParameterValues("questions[]");
            String[] optionA = request.getParameterValues("option_a[]");
            String[] optionB = request.getParameterValues("option_b[]");
            String[] optionC = request.getParameterValues("option_c[]");
            String[] optionD = request.getParameterValues("option_d[]");
            String[] correctAnswers = request.getParameterValues("correct_answer[]");

            for (int i = 0; i < questions.length; i++) {
                String questionQuery = "INSERT INTO questions (course_id, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement questionPs = connection.prepareStatement(questionQuery);
                questionPs.setInt(1, courseId);
                questionPs.setString(2, questions[i]);
                questionPs.setString(3, optionA[i]);
                questionPs.setString(4, optionB[i]);
                questionPs.setString(5, optionC[i]);
                questionPs.setString(6, optionD[i]);
                questionPs.setString(7, correctAnswers[i]);
                questionPs.executeUpdate();
                questionPs.close();
            }

            coursePs.close();
            connection.close();

            // Redirect to settings or another page after successful addition
          RequestDispatcher dispatcher = request.getRequestDispatcher("addCourse.jsp");
request.setAttribute("message", "Course added successfully!");
dispatcher.forward(request, response);

        } catch (Exception e) {
            
            
        }
    }
}
