package demoU;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class GetAssignmentServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Set up the connection
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "root");

            String query = "SELECT project_title FROM Courses WHERE course_id = ?";
            stmt = con.prepareStatement(query);
            stmt.setInt(1, courseId);
            rs = stmt.executeQuery();

            // Prepare the JSON response
            StringBuilder jsonResponse = new StringBuilder();
            jsonResponse.append("[");

            boolean first = true;
            while (rs.next()) {
                if (!first) {
                    jsonResponse.append(", ");
                }
                first = false;

                String projectTitle = rs.getString("project_title");

                jsonResponse.append("{");
                jsonResponse.append("\"project_title\":\"").append(projectTitle).append("\"");
                jsonResponse.append("}");
            }

            jsonResponse.append("]");

            // Set response content type to JSON
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.print(jsonResponse.toString());
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
