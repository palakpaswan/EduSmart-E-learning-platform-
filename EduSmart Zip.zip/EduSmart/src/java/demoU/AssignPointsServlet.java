package demoU;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AssignPointsServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fileName = request.getParameter("fileName");
        String userName = request.getParameter("userName");
        int points = Integer.parseInt(request.getParameter("points"));

        // Database configuration
        String dbURL = "jdbc:mysql://localhost:3306/User";
        String dbUser = "root";
        String dbPassword = "root";

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Update points in the database
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(dbURL, dbUser, dbPassword);

            // Update the Assignment table to set the points for the specific file
            String updateQuery = "UPDATE Assignment SET points = ? WHERE file_name = ? and username = ?";
            PreparedStatement pstmt = con.prepareStatement(updateQuery);
            pstmt.setInt(1, points);
            pstmt.setString(2, fileName);
            pstmt.setString(3, userName);
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                out.println("<br><br><br><hr><h1 style=font-size:60px;color:green>Points Assigned Successfully!!!<h1><hr>");
            } else {
                out.println("<h3>Error: Assignment not found or points not updated.</h3>");
            }

            con.close();
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }

        out.println("<a href='tutorPage.jsp'>Back to Tutor Page</a>");
    }
}
