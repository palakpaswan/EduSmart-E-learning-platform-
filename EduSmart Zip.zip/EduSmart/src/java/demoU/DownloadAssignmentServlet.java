package demoU;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DownloadAssignmentServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fileName = request.getParameter("fileName");
        String assignmentDir = "D:/uploads"; // Updated directory path
        File file = new File(assignmentDir + File.separator + fileName);

        if (file.exists()) {
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

            FileInputStream fis = new FileInputStream(file);
            OutputStream os = response.getOutputStream();

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }

            fis.close();
            os.close();
        } else {
            response.getWriter().println("File not found.");
        }
    }
}
