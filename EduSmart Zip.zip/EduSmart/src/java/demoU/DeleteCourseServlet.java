package demoU;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class DeleteCourseServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int courseId = Integer.parseInt(request.getParameter("course_id"));

        // Print received course_id for debugging
        System.out.println("Received course_id: " + courseId);

        Connection connection = null;
        PreparedStatement ps = null;
        PreparedStatement deleteEnrollmentsPs = null;

        try {
            // Connect to the database
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "root");

            // Disable auto-commit for transaction management
            connection.setAutoCommit(false);

            // Delete enrollments that reference the course
            String deleteEnrollmentsQuery = "DELETE FROM enrollments WHERE course_id = ?";
            deleteEnrollmentsPs = connection.prepareStatement(deleteEnrollmentsQuery);
            deleteEnrollmentsPs.setInt(1, courseId);
            int deletedEnrollments = deleteEnrollmentsPs.executeUpdate();
            System.out.println("Deleted enrollments: " + deletedEnrollments);

            // Delete the course after the enrollments are removed
            String deleteCourseQuery = "DELETE FROM courses WHERE course_id = ?";
            ps = connection.prepareStatement(deleteCourseQuery);
            ps.setInt(1, courseId);
            int deletedCourse = ps.executeUpdate();
            System.out.println("Deleted course: " + deletedCourse);
            
            String deleteTestQuery = "DELETE FROM questions WHERE course_id = ?";
            ps = connection.prepareStatement(deleteTestQuery);
            ps.setInt(1, courseId);
            int deletedTest = ps.executeUpdate();
            System.out.println("Deleted test: " + deletedTest);
            

            // Commit the transaction
            connection.commit();

            // Send success response
            response.sendRedirect("settings.jsp");

        } catch (Exception e) {
            // If any error occurs, rollback the transaction
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            // Log the exception and send error response
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error deleting course: " + e.getMessage());
        } finally {
            try {
                // Close all resources
                if (deleteEnrollmentsPs != null) deleteEnrollmentsPs.close();
                if (ps != null) ps.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
