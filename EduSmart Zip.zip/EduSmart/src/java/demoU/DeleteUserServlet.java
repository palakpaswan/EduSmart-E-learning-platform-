package demoU;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DeleteUserServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String userType = request.getParameter("userType"); // "student", "parent", or "tutor"

        Connection connection = null;
        PreparedStatement psDeleteEnrollments = null;
        PreparedStatement psDeleteQueries = null;
        PreparedStatement psDeleteAssignments = null;
        PreparedStatement psDeleteUser = null;
        Statement disableFKCheck = null;

        try {
            // Establish database connection
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "root");

            if ("student".equalsIgnoreCase(userType)) {
                // Disable foreign key checks
                disableFKCheck = connection.createStatement();
                disableFKCheck.execute("SET FOREIGN_KEY_CHECKS = 0;");

                // Delete associated records from dependent tables for student
                String deleteEnrollmentsQuery = "DELETE FROM enrollments WHERE username = ?";
                String deleteQueriesQuery = "DELETE FROM student_queries WHERE username = ?";
                String deleteAssignmentsQuery = "DELETE FROM assignment WHERE username = ?";
                String deleteStudentQuery = "DELETE FROM students WHERE username = ?";

                psDeleteEnrollments = connection.prepareStatement(deleteEnrollmentsQuery);
                psDeleteEnrollments.setString(1, username);
                psDeleteEnrollments.executeUpdate();

                psDeleteQueries = connection.prepareStatement(deleteQueriesQuery);
                psDeleteQueries.setString(1, username);
                psDeleteQueries.executeUpdate();

                psDeleteAssignments = connection.prepareStatement(deleteAssignmentsQuery);
                psDeleteAssignments.setString(1, username);
                psDeleteAssignments.executeUpdate();

                psDeleteUser = connection.prepareStatement(deleteStudentQuery);
                psDeleteUser.setString(1, username);
                psDeleteUser.executeUpdate();

                // Re-enable foreign key checks
                disableFKCheck.execute("SET FOREIGN_KEY_CHECKS = 1;");
                disableFKCheck.close();
                response.sendRedirect("manageUsers.jsp");

            } else if ("parent".equalsIgnoreCase(userType)) {
                // Simple deletion for parent
                String deleteParentQuery = "DELETE FROM parents WHERE username = ?";
                psDeleteUser = connection.prepareStatement(deleteParentQuery);
                psDeleteUser.setString(1, username);
                psDeleteUser.executeUpdate();
                response.sendRedirect("manageUsers.jsp");

            } else if ("tutor".equalsIgnoreCase(userType)) {
                // Simple deletion for tutor
                String deleteTutorQuery = "DELETE FROM tutors WHERE username = ?";
                psDeleteUser = connection.prepareStatement(deleteTutorQuery);
                psDeleteUser.setString(1, username);
                psDeleteUser.executeUpdate();
                response.sendRedirect("manageUsers.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("An error occurred while deleting the user.");
        } finally {
            try {
                if (psDeleteEnrollments != null) psDeleteEnrollments.close();
                if (psDeleteQueries != null) psDeleteQueries.close();
                if (psDeleteAssignments != null) psDeleteAssignments.close();
                if (psDeleteUser != null) psDeleteUser.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
