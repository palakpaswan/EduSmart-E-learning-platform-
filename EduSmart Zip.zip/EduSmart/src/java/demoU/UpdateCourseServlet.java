package demoU;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class UpdateCourseServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int courseId = Integer.parseInt(request.getParameter("course_id"));
        String courseName = request.getParameter("course_name");
        String videoUrl = request.getParameter("video_url");

        Connection connection = null;

        try {
            // Setup database connection
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "root");

            // Update course details
            String updateCourseQuery = "UPDATE courses SET course_name = ?, video_url = ? WHERE course_id = ?";
            PreparedStatement coursePs = connection.prepareStatement(updateCourseQuery);
            coursePs.setString(1, courseName);
            coursePs.setString(2, videoUrl);
            coursePs.setInt(3, courseId);
            coursePs.executeUpdate();

            // Update each question dynamically
            int totalQuestions = Integer.parseInt(request.getParameter("total_questions"));
            for (int i = 1; i <= totalQuestions; i++) {
                int questionId = Integer.parseInt(request.getParameter("question_id_" + i));
                String questionText = request.getParameter("question_text_" + i);
                String optionA = request.getParameter("option_a_" + i);
                String optionB = request.getParameter("option_b_" + i);
                String optionC = request.getParameter("option_c_" + i);
                String optionD = request.getParameter("option_d_" + i);
                String correctAnswer = request.getParameter("correct_answer_" + i);

                String updateQuestionQuery = "UPDATE questions SET question_text = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_answer = ? WHERE question_id = ?";
                PreparedStatement questionPs = connection.prepareStatement(updateQuestionQuery);
                questionPs.setString(1, questionText);
                questionPs.setString(2, optionA);
                questionPs.setString(3, optionB);
                questionPs.setString(4, optionC);
                questionPs.setString(5, optionD);
                questionPs.setString(6, correctAnswer);
                questionPs.setInt(7, questionId);
                questionPs.executeUpdate();
            }

            RequestDispatcher dispatcher = request.getRequestDispatcher("updateCourse.jsp");
request.setAttribute("message", "Course details updated successfully!");
dispatcher.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error updating course and questions");
        } finally {
            try {
                if (connection != null) connection.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
