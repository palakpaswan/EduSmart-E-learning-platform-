package demoU;

import java.io.*;
import java.nio.file.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;

@MultipartConfig
public class Upload_Servlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get file and course details from the form
        String path = "D:/uploads"; // You can update this to a suitable location on your server
        Part filePart = request.getPart("file");
        String filename = filePart.getSubmittedFileName();
        Path path1 = Paths.get(filename);
        String fileNameForDB = path1.getFileName().toString(); // For storing in the database

        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String courseId = request.getParameter("course");

        if (username == null) {
            response.sendRedirect("login.html");
            return;
        }

        // Save the file to the specified path
        OutputStream os = null;
        InputStream is = null;
        try {
            File uploadDir = new File(path);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs(); // Create the directory if it doesn't exist
            }

            os = new FileOutputStream(new File(uploadDir, fileNameForDB));
            is = filePart.getInputStream();
            int read;
            while ((read = is.read()) != -1) {
                os.write(read);
            }

            // Update the database with assignment details
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "root");

                String query = "INSERT INTO Assignment (username, course_id, file_name) VALUES (?, ?, ?)";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, username);
                stmt.setInt(2, Integer.parseInt(courseId));
                stmt.setString(3, fileNameForDB);

                int rowsInserted = stmt.executeUpdate();
                if (rowsInserted > 0) {
                    out.println("<br><br><br><hr><h1 style=font-size:60px;color:green>Assignment Submitted Successfully!!!<h1><hr>");
                    out.println("<a href='Assignment.jsp'>Click to submit more assignments </a>");
                } else {
                    out.println("<br><br><br><hr><b>Failed to Submit Assignment. Please Try Again.<b>");
                }

                stmt.close();
                con.close();
            } catch (Exception e) {
                out.println("<br><br><br><hr><b>Database Error: " + e.getMessage() + "</b>");
            }
        } catch (FileNotFoundException e) {
            out.print("<br><br><hr><b>Error: " + e.getMessage() + "</b>");
        } finally {
            if (os != null) os.close();
            if (is != null) is.close();
        }
    }
}
