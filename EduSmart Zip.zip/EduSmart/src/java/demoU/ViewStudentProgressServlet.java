package demoU;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.*;
import javax.servlet.http.*;

public class ViewStudentProgressServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String parentUsername = (String) request.getSession().getAttribute("username");
        String studentUsername = request.getParameter("studentUsername");

        if (parentUsername == null) {
            response.sendRedirect("login.html");
            return;
        }

        if (studentUsername == null || studentUsername.trim().isEmpty()) {
            request.setAttribute("error", "Please provide a valid student's username.");
            request.getRequestDispatcher("parentDashboard.jsp").forward(request, response);
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/User", "root", "root")) {
            // Fetch enrolled courses
            List<Course> enrolledCourses = fetchEnrolledCourses(conn, studentUsername);

            // Fetch assignments
            List<Assignment> assignments = fetchAssignments(conn, studentUsername);

            // Set attributes and forward to JSP
            request.setAttribute("studentUsername", studentUsername);
            request.setAttribute("enrolledCourses", enrolledCourses);
            request.setAttribute("assignments", assignments);
            request.getRequestDispatcher("parentDashboard.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace(); // Log the error
            request.setAttribute("error", "An error occurred while fetching the data. Please try again later.");
            request.getRequestDispatcher("parentDashboard.jsp").forward(request, response);
        }
    }

    private List<Course> fetchEnrolledCourses(Connection conn, String studentUsername) throws SQLException {
        List<Course> enrolledCourses = new ArrayList<>();
        String courseQuery = "SELECT c.course_name, e.video_watched, e.test_passed, e.enrollment_date " +
                             "FROM enrollments e " +
                             "JOIN courses c ON e.course_id = c.course_id " +
                             "WHERE e.username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(courseQuery)) {
            stmt.setString(1, studentUsername);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                enrolledCourses.add(new Course(
                    rs.getString("course_name"),
                    rs.getInt("video_watched"),
                    rs.getInt("test_passed"),
                    rs.getDate("enrollment_date").toString()
                ));
            }
        }
        return enrolledCourses;
    }

    private List<Assignment> fetchAssignments(Connection conn, String studentUsername) throws SQLException {
        List<Assignment> assignments = new ArrayList<>();
        String assignmentQuery = "SELECT a.file_name, a.submission_date, a.points " +
                                 "FROM assignment a " +
                                 "WHERE a.username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(assignmentQuery)) {
            stmt.setString(1, studentUsername);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                assignments.add(new Assignment(
                    rs.getString("file_name"),
                    rs.getDate("submission_date").toString(),
                    rs.getInt("points")
                ));
            }
        }
        return assignments;
    }

    private static class Course {
        String courseName;
        int videoWatched;
        int testPassed;
        String enrollmentDate;

        Course(String courseName, int videoWatched, int testPassed, String enrollmentDate) {
            this.courseName = courseName;
            this.videoWatched = videoWatched;
            this.testPassed = testPassed;
            this.enrollmentDate = enrollmentDate;
        }

        public String getCourseName() {
            return courseName;
        }

        public int getVideoWatched() {
            return videoWatched;
        }

        public int getTestPassed() {
            return testPassed;
        }

        public String getEnrollmentDate() {
            return enrollmentDate;
        }
    }

    private static class Assignment {
        String fileName;
        String submissionDate;
        int points;

        Assignment(String fileName, String submissionDate, int points) {
            this.fileName = fileName;
            this.submissionDate = submissionDate;
            this.points = points;
        }

        public String getFileName() {
            return fileName;
        }

        public String getSubmissionDate() {
            return submissionDate;
        }

        public int getPoints() {
            return points;
        }
    }
}
